export const testDataSet = {
    claimsBaseUrl: "http://localhost:62911", // https://dva-intpro-claims.soa.testroyallondongroup.com
    planForNewClaim: "90776180",
    planForExistingClaim: "90776180"
};