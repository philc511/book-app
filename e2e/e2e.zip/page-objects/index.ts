export * from "./components";
export * from "./app.po";
export * from "./dashboard.po";
export * from "./death.po";
export * from "./idv.po";
export * from "./side-bar.po";
export * from "./summary.po";
